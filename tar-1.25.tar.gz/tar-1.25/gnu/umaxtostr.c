/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define anytostr umaxtostr
#define inttype uintmax_t
#define inttype_is_signed 0
#include "anytostr.c"
